package com.cg.employee.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.employee.bean.Address;
import com.cg.employee.bean.Employee;
import com.cg.employee.daoservices.EmployeeDAO;
import com.cg.employee.exceptions.EmployeeDetailNotFoundException;


@Component("employeeServices")
public class EmployServicesImpl implements EmployServices {
	
	@Autowired
	private EmployeeDAO employeeDAO;
	

	@Override
	public Employee acceptEmployeeDetails(Employee employee) {
		employee =employeeDAO.save(employee);
		return  employee;
	}

	@Override
	public Employee getEmployeeDetails(int employeeId) throws EmployeeDetailNotFoundException {
		Employee employee = employeeDAO.findById(employeeId).orElseThrow(()->new EmployeeDetailNotFoundException("Employee Details not found for assocoiate Id :- "+employeeId));		
		return employee;
	}
	@Override
	public List<Employee> getAllEmployeeDetails() {
		
		return employeeDAO.findAll();
	}

	@Override
	public boolean removeEmployeeDetails(int employeeId) throws EmployeeDetailNotFoundException {
		employeeDAO.delete(getEmployeeDetails(employeeId));
		return true;
	}

	@Override
	public void savedData(Employee employee) {
		employeeDAO.save(employee);
	}

	@Override
	public boolean updateEmployeeDetails(int employeeId, Employee employee) throws EmployeeDetailNotFoundException {
		getEmployeeDetails(employeeId);
		employee.setEmployeeId(employeeId);
		employeeDAO.save(employee);
		return true;
	}

	@Override
	public Address aaceptAddressDetails(Address address) {
		
		return null;
	}
	
	
	
}