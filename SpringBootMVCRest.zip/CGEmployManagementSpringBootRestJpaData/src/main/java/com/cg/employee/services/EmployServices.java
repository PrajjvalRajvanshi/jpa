package com.cg.employee.services;

import java.util.List;

import com.cg.employee.bean.Address;
import com.cg.employee.bean.Employee;
import com.cg.employee.exceptions.EmployeeDetailNotFoundException;

public interface EmployServices {
Employee acceptEmployeeDetails(Employee employee);

Employee getEmployeeDetails(int employeeId)throws EmployeeDetailNotFoundException;

List<Employee> getAllEmployeeDetails();

boolean removeEmployeeDetails(int employeeId) throws EmployeeDetailNotFoundException;
void savedData(Employee employee);
boolean updateEmployeeDetails(int employeeId,Employee employee) throws EmployeeDetailNotFoundException;

Address aaceptAddressDetails(Address address);
}
