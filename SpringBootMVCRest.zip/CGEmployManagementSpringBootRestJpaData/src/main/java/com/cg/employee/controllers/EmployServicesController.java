package com.cg.employee.controllers;

import java.util.List;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.employee.bean.Address;
import com.cg.employee.bean.Employee;
import com.cg.employee.daoservices.EmployeeDAO;
import com.cg.employee.exceptions.EmployeeDetailNotFoundException;
import com.cg.employee.services.EmployServices;

@Controller
public class EmployServicesController {

		@Autowired
		 EmployServices employeeServices;
		
		@RequestMapping(value= {"/getEmployeeDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
				headers="Accept=application/json")
		public ResponseEntity<Employee> getAssociateDetailsRequestPathParam(@RequestParam int employeeId)throws EmployeeDetailNotFoundException
		{
			Employee employee  = employeeServices.getEmployeeDetails(employeeId);
			return new ResponseEntity<Employee>(employee,HttpStatus.OK);
		}
		
		@RequestMapping(value= {"/getAllEmployeeDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
				headers="Accept=application/json")
		public ResponseEntity<List<Employee>> getAllAssociateDetailsPathParam()throws EmployeeDetailNotFoundException{
			return new ResponseEntity<List<Employee>>(employeeServices.getAllEmployeeDetails(),HttpStatus.OK);
		}
		@RequestMapping(value= {"/acceptEmployeeDetails"},method=RequestMethod.POST,produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
		public ResponseEntity<String> acceptAssociateDetails(@ModelAttribute Employee employee){
			employee = employeeServices.acceptEmployeeDetails(employee);
			return new ResponseEntity<>("Employee details successfully added and Employee ID is "+employee.getEmployeeId(),HttpStatus.OK);
		}
		@RequestMapping(value= {"/removeEmployeeDetails"},method=RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
		public  ResponseEntity<String> removeAssociateDetailsRequestParam(@RequestParam int employeeId)throws EmployeeDetailNotFoundException
		{
			employeeServices.removeEmployeeDetails(employeeId);
			return new ResponseEntity<>("Employee details successfully Removed",HttpStatus.OK);
		}
		
	
	  @RequestMapping(value={"/updateEmployeeDetails"},method=RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json") 
	  public ResponseEntity<Boolean> getAssociateDetailsRequestPathParam(@RequestParam int employeeId,@ModelAttribute Employee employee)throws EmployeeDetailNotFoundException 
		  {
	      boolean result = employeeServices.updateEmployeeDetails(employeeId,employee);
	  return new ResponseEntity<Boolean>(result,HttpStatus.OK); }
	 
}
