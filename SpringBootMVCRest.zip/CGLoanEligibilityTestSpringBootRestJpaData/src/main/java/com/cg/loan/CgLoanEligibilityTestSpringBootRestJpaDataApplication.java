package com.cg.loan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgLoanEligibilityTestSpringBootRestJpaDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgLoanEligibilityTestSpringBootRestJpaDataApplication.class, args);
	}

}
